
MK5 8G/16G GIGA cart upgrade core V1.23A+  [02-23-2007]

history:
* the save data upgrade to #947, game compatibility = 100%!
* change the MK5 skin, more colorful
* moonshell upgrade to V1.71, movie play speed up! And support TTA/AAC/OGG !
* dpgtools upgrade to V1.3 , more stable

more info check here: http://www.neoflash.com/forum/index.php/board,78.0.html
download: http://www.neoflash.com/download/mk5_1.23A_plus_upgrade.rar 

how to upgrade: (without format)
[1] link your MK5 to pc through the MK5 USB linker;
[2] unzip this rar pack,and enter the "Driver" folder ,copy all files to your MK5 and overwrite the old files,and stop the MK5 removeable disk when it's done;
[3] remove the MK5 USB linker,turn on nds and enter the menu,click and run "mk5_update_fat_new_V1.23A+.nds"
[4] turn off nds,now upgrade finish,enjoy it!


how to upgrade: (with format)
[1] If your MK5 can't enter the menu to upgrade,you can try to format it on NDS (warnning: this upgrade will format MK5 and all old data will be destory!), please follow me:
    <a> plug in the USB cart to GBA slot and link to PC,and plug in the MK5 to NDS slot;
    <b> hold the "L" + "R" + "DOWN" and turn on NDS till you see the mk5 logo appear (don't release these 3 keys), and press "A"+"B" (now 5 keys were hold) ,then you can see USB cart start to formatting MK5. When if finish(around 5 seconds),you can see "USB DISK PROGRAM(8G/16G_256K)" appear on the NDS screen, PC will appear one USB DISK too;
[2] Now you can follow the "how to upgrade: (without format)" to upgrade MK5 again.


-----------------------------------------------------------

MK5 8G/16G GIGA cart upgrade core V1.23A  [17-02-2007]

history:
* support the DLDI,and open the DLDI source code
* support CRC write checksum,read/write is more safety
* fix few roms running bug
* moonshell play movie more smooth now,and upgrade to V1.5
* support MK5 joypad and MK5 mouse,and open the source code
* dpgtools upgrade to v1.21 ,support more video format


-----------------------------------------------------------
NEOTEAM 2007
www.NEOFLASH.com