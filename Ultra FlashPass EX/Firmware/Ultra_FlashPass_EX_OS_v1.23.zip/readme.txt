1. Just like a normal NDS file, copy the NDS file ufpex_8G_auto123.nds into Ultra FlashPass EX 8.0G.
2. Run the ufpex_8G_auto123.nds file.
3. Follow the instruction.
4. Upgrade complete.

www.NDSGBA.net