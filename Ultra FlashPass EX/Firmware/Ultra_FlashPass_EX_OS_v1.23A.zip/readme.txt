Q:How to upgrade the firmware of Ultra FlashPass EX (UFPEX) to 1.23A?
Important: This upgrade operation need to format UFPEX, please backup your game and save first. 
1.Insert UFPEX Writer into slot 2 and insert UFPEX into slo 1.
2.Use USB cable connect to PC USB port directly. (Please do not use extension USB cable)
3.Hold the "up" directionnal button and turn on power.
4.still holding "up", press "L+R+A+B", will enter upgrade mode, a red color message will appear.
5.Double click 
"NAND_2G_128K" For UFPEX 2.0G
"NAND_4G_128K" For UFPEX 4.0G
"NAND_8G_256K" For UFPEX 8.0G
"NAND_16G_256K" For UFPEX 16G 
to run upgrade program. If there some "found a badblock" appear, that mean it doesn't work, please change a PC USB port or USB cable and try again.
6.Format UFPEX, it will work again.

Q: How to format UFPEX? (New firmware do not need "flashformat" program to format)
1. Insert UFPEX Writer into slot 2 and insert UFPEX into slo 1.
2. Hold the "down" directionnal button and turn on power
3. still holding "down", press "L+R+A+B", will enter format program mode and will do low level format and high level format together.
4. Now, PC can recognise UFPEX as a USB disk.
5. Copy the "DSYSTEM" folder into UFPEX root.

Q: What's new of this firmware?
1.Support Moonshell 1.6 Movie with fluency (Please download Moonshell for UFPEX from soft page).
2.Optimized FAT file system.
3.Open FAT I/O Source, easy for programmer make homwbrew.
4.Open USB Plugin Source, easy for programmer make USB application.
5.Support PDA software DSOrganize(Please download DSOrgainze for UFPEX from soft page).


www.NDSGBA.net