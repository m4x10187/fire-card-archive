/*---------------------------------------------------------------------------------
---------------------------------------------------------------------------------*/

#include "nds.h"
#include <nds/arm9/console.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "usbhal.h"
#include "usb.h"
#include "usbcfg.h"
#include "usbhw.h"
#include "usbcore.h"
#include "debug.h"






//---------------------------------------------------------------------------------
int main(void) {
//---------------------------------------------------------------------------------
	
	sysSetBusOwners(1,1);
	
	videoSetMode(0);	//not using the main screen
	videoSetModeSub(MODE_0_2D | DISPLAY_BG0_ACTIVE);	//sub bg 0 will be used to print text
	vramSetBankC(VRAM_C_SUB_BG);
	SUB_BG0_CR = BG_MAP_BASE(31);
	{
		u32 i;
		for(i=0;i<256;i++)
			BG_PALETTE_SUB[i] = RGB15(0,0,0);
	}
	BG_PALETTE_SUB[255] = RGB15(31,31,31);	//by default font will be rendered with color 255
	//consoleInit() is a lot more flexible but this gets you up and running quick
	consoleInitDefault((u16*)SCREEN_BASE_BLOCK_SUB(31), (u16*)CHAR_BASE_BLOCK_SUB(0), 16);
	
	printf("NDS GAMEPAD V1.2\n");

	u16 tmp=*(vu16*)0x04000204;
	tmp&=~0x1F;
	tmp|=0x1A;
	*(vu16*)0x04000204=tmp;
	D14_ID;
	D14_ID;
	D14_ID;
	D14_ID;

	if(D14_ID!=0x8151)
	{
		printf("USBCard init failed!\n");
		while(1);
	}

	printf("USBCard init ok!\n");

	D14USBInit();

	USB_Connect(1);

	while(1)
	{
		USB_ISR();
	}

	return 0;
}
