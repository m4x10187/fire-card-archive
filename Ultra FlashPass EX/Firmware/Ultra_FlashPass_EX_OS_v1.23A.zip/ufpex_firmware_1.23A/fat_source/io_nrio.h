/*
 io_nrio.h 

 2006-10-29  create by gaojian
*/

#ifndef io_nrio_H
#define io_nrio_H

#define DEVICE_TYPE_NRIO 0x4F49524E

#include "disc_io.h"

// export interface
extern const IO_INTERFACE _io_nrio ;

#endif	// define io_nrio_H
